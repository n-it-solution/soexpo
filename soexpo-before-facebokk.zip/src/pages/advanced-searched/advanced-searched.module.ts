import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdvancedSearchedPage } from './advanced-searched';

@NgModule({
  declarations: [
    AdvancedSearchedPage,
  ],
  imports: [
    IonicPageModule.forChild(AdvancedSearchedPage),
  ],
})
export class AdvancedSearchedPageModule {}
