import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ProDetailPage } from './pro-detail';

@NgModule({
  declarations: [
    ProDetailPage,
  ],
  imports: [
    IonicPageModule.forChild(ProDetailPage),
  ],
})
export class ProDetailPageModule {}
