import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Contact1Page } from './contact1';

@NgModule({
  declarations: [
    Contact1Page,
  ],
  imports: [
    IonicPageModule.forChild(Contact1Page),
  ],
})
export class Contact1PageModule {}
