import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { About1Page } from './about1';

@NgModule({
  declarations: [
    About1Page,
  ],
  imports: [
    IonicPageModule.forChild(About1Page),
  ],
})
export class About1PageModule {}
